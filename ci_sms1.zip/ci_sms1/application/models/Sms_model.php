<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 class Sms_model extends CI_Model
 {
  	function add_user($data)
	{
		$result = $this->db->insert("sms_login",$data);
		print_r($result);
	}
	function login($email,$password)
	{
		
	}
 }
?>