<?php 
class Sms extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('sms_model');
		$urldata = $this->uri->segment(3);
		// echo $urldata;
		
		/*if($this->session->userdata('status'))
		{
	
			if(in_array($urldata, url_after_login()))
			{
				redirect(base_url().'index.php/sms/index');
			}
		}

		if(!$this->session->userdata('status')){

			if(in_array($urldata, url_before_login())){
				redirect(base_url().'index.php/sms/logout');
			}
		}*/	
	}

	public function index()
	{
		$this->load->view('index');
	}
	function login()
	{
		$this->load->view('login');
	}

	public function register_action()
	{
		echo "<pre>";
			print_r($_POST);
		echo "</pre>";

		$ans = $this->input->post();
		// pre($ans);
		$this->form_validation->set_rules('log_name','Name :','trim|required|regex_match[/^[a-zA-Z][a-zA-Z ]+[a-zA-Z]$/]');

		$this->form_validation->set_rules('log_email','Email:','trim|required|valid_email|is_unique[sms_login.log_email]');

		$this->form_validation->set_rules('log_mobile','Mobile:','trim|required|integer|exact_length[10]');

		$this->form_validation->set_rules('log_pass','Password:','trim|required|alpha_dash|min_length[4]|max_length[10]|matches[log_cpass]');

		$this->form_validation->set_rules('log_cpass','Confirm Password:','trim|required|alpha_numeric|min_length[4]|max_length[10]|matches[log_pass]');

		$this->form_validation->set_message('matches', 'password and confirm password does not match');

		if($this->form_validation->run()==FALSE)
		{
			echo validation_errors();
			//$this->index();
		}		
		else
		{
			echo "done";
			// $_POST['log_pass']=do_hash($_POST['log_pass']);

			//  $data = array(
   //            	'log_name'=>$this->input->post('log_name'),
   //            	'log_email'=>$this->input->post('log_email'),
   //            	'log_mobile'=>$this->input->post('log_mobile'),
   //            	'log_pass'=>md5($this->input->post('log_pass')),
   //            	'log_cpass'=>md5($this->input->post('log_cpass'))
   //          );
			
			// $lastid=$this->sms_model->register_action($data);
			// $email=$this->input->post('log_email');
			//$url= base_url()."index.php/sms/activate_user/$lastid";
			// echo "User Added";
			//unset($_POST['log_cpass']);
			$_POST['log_pass'] = do_hash($_POST['log_pass']);
			// pre($_POST);
			$ans = $this->login_model->add_user("sms_login",$_POST);
			if($ans){echo "Record Added";}
		}

	}

	function aboutus()
	{
		$this->load->view('about-us');
	}
	function contactus()
	{
		$this->load->view('contact-us');
	}
	function addcontact()
	{
		$this->load->view('add-contact');
	}
	function forgetpass()
	{
		$this->load->view('forget-password');
	}
	function changepass()
	{
		$this->load->view('changepass');
	}
	function library()
	{
		$this->load->view('library');
	}

	function createmessage()
	{
		$this->load->view('create-message');
	}
}



?>