<?php 
class Sms extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('sms_model');
		$urldata = $this->uri->segment(3);		
	}

	public function index()
	{
		$this->load->view('index');
	}
	function login()
	{
		$this->load->view('login');
	}

	public function register_action()
	{
		echo "<pre>";
			print_r($_POST);
		echo "</pre>";

		$ans = $this->input->post();
		// pre($ans);
		$this->form_validation->set_rules('log_name','Name :','trim|required|alpha_numeric_spaces|min_length[2]|max_length[50]');

		$this->form_validation->set_rules('log_email','Email:','trim|required|valid_email|is_unique[sms_login.log_email]');

		$this->form_validation->set_rules('log_mobile','Mobile:','trim|required|integer|exact_length[10]');

		$this->form_validation->set_rules('log_pass','Password:','trim|required|alpha_dash|min_length[4]|max_length[10]');

		$this->form_validation->set_rules('log_cpass','Confirm Password:','trim|required|alpha_dash|min_length[4]|max_length[10]|matches[log_pass]');


		if($this->form_validation->run()==FALSE)
		{
			echo validation_errors();
			//$this->index();
		}		
		else
		{
			//echo "done";
			if($_POST['log_pass'] == $_POST['log_cpass'])
			{
				$_POST['log_pass'] = do_hash($_POST['log_pass']);
				// pre($_POST);
				unset($_POST['log_cpass']);
				$ans = $this->sms_model->add_user($_POST);
				if($ans){echo "done";}
			}
			else
			{
				echo "Password and Confirm Password should be same";
			}
		}
	}
	public function login_action()
	{
		echo "<pre>";
			print_r($_POST);
		echo "</pre>";

		$ans = $this->input->post();

		$this->form_validation->set_rules('log_email','Email:','trim|required|valid_email|is_unique[sms_login.log_email]');

		$this->form_validation->set_rules('log_pass','Password:','trim|required|alpha_dash|min_length[4]|max_length[10]');

		if($this->form_validation->run()==FALSE)
		{
			echo validation_errors();
			//$this->index();
		}
		else
		{
			
		}
	}

	function aboutus()
	{
		$this->load->view('about-us');
	}
	function contactus()
	{
		$this->load->view('contact-us');
	}
	function addcontact()
	{
		$this->load->view('add-contact');
	}
	function forgetpass()
	{
		$this->load->view('forget-password');
	}
	function changepass()
	{
		$this->load->view('changepass');
	}
	function library()
	{
		$this->load->view('library');
	}

	function createmessage()
	{
		$this->load->view('create-message');
	}
}



?>