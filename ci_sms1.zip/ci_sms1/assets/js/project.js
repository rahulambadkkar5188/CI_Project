$(document).ready(function(){
	var apath = "http://localhost/rahula/ci_sms1/index.php/sms/";

	$(".reg_btn").click(function(){ 
        $.ajax({
            type:"post",
            data:$("#register_form").serialize(),            
            url:apath+"register_action",
            success:function(res){
                if(res != "done")
                {
                    $(".err_reg").html(res)
                }
            }
        })
    })

	$(".log_btn").click(function(){
		$.ajax({
			type: "post",
            data:$("#login_form").serialize(),
			url: apath+"login_action",
			success:function(res){
				alert(res);
				if(res != "done")
                {
                    $(".err_log").html(res)
                }
			}
		})
	});

});