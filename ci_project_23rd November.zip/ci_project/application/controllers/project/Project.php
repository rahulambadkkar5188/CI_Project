<?php

/**
 * 
 */
class Project 
{
	
function index()	{
		# code...
	echo "test";
	}
}
?>