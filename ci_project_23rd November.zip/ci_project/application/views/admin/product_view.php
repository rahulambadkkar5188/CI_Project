<?php
$this->load->view('admin/header');
?>

<div class="container-fluid">
  <div class="card card-register mx-auto mt-5">
        <div class="card-header">Product Page</div>
        <div class="card-body">
          <form id="product_form">
              
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputBrand" name="name" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">Nike</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputBrand" name="price" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">2500</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputBrand" name="discount" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">20 in %</label>
              </div>
            </div>

            <div class="form-group">
              <div class="form-label-group">
                <select class="form-control" name="category_id">
                  <option>Please Select Category</option>
                  <?php
                    if(is_array($x1)):
                      foreach($x1 as $key=>$val):
                  ?>
                  <option value="<?php echo $val['id'];?>"><?php echo $val['name'];?></option>
                  <?php
                      endforeach;
                    endif;
                  ?>
                </select>
              </div>
            </div>

            <div class="form-group">
              <div class="form-label-group">
                <select class="form-control" name="brand_id">
                  <option>Please Select Brand</option>
                  <?php
                    if(is_array($x2)):
                      foreach($x2 as $key=>$val):
                  ?>
                  <option value="<?php echo $val['id'];?>"><?php echo $val['name'];?></option>
                  <?php
                      endforeach;
                    endif;
                  ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="file" id="inputBrand" name="path" class="form-control" placeholder="Email address" required="required">
              </div>
            </div>

            <div class="form-group">
              <div class="form-label-group">
                <textarea name="description" class="form-control" placeholder="Enter Product description" required="required"></textarea>
              </div>
            </div>
            
            <button type="button" class="btn btn-primary btn-block btn-brand">Add</button>
          </form>
        </div>
            <div class="brand_err">  </div>
      </div>
</div>


<?php
	$this->load->view('admin/footer');
?>
        
 