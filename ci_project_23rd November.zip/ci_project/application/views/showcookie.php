<?php
echo get_cookie('username');
?>
    <a href="<?php echo base_url();
        ?>index.php/project/cookie3/">Delete</a>