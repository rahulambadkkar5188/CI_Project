<?php

echo form_open('project/actionPage');
?>