<div class="left-sidebar">
						<h2>Category</h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->

							
							<?php 
									$x1 = $this->myclass->get_category();
									if(is_array($x1)):
										foreach($x1 as $val):
							?>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a href="<?php echo client().'filtercat/'.$val['id']?>">
											<?php echo $val['name']?>
										</a>
									</h4>
								</div>
							</div>
							<?php
 							   endforeach;
 							 endif;
							?>
							</div>
							
						</div><!--/category-products-->
					
						<div class="brands_products"><!--brands_products-->
							<h2>Brands</h2>
							
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
						<?php 
							$x2 = $this->myclass->get_brand();
							if(is_array($x2)):
								foreach($x2 as $val):
						?>
									<li><a href="#" for="<?php echo $val['id'];?>" class="filter_brand"> 
										<span class="pull-right">(50)</span><?php echo $val['name'];?></a>
									</li>
						<?php
 							  endforeach;
 							endif;
						?>
								</ul>
							</div>
						
						</div><!--/brands_products-->
						
						
						<div class="price-range"><!--price-range-->
							<h2>Price Range</h2>
							<div class="well text-center">
								 <input type="text" class="span2" value="" data-slider-min="0" data-slider-max="600" data-slider-step="5" data-slider-value="[250,450]" id="sl2" ><br />
								 <b class="pull-left">$ 0</b> <b class="pull-right">$ 600</b>
							</div>
						</div><!--/price-range-->
						
						<div class="shipping text-center"><!--shipping-->
							<img src="<?php echo path();?>images/home/shipping.jpg" alt="" />
						</div><!--/shipping-->
					
					</div>