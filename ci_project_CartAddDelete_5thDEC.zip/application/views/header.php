<html>
<head>
        <title>My Blog</title>
</head>
<body>
        <h1>Welcome to header</h1>
</body>
</html>