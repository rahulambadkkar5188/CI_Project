<?php
	class Admin_model extends CI_Model
	{
		function add_user($data)
		{
			$result = $this->db->insert("users",$data);
			//print_r($result);

			return $this->db->insert_id();
		}//add_user

		function user_activation_process($id)
		{
			$arr = array(
              "ustatus" => 1
			);

			$this->db->where("uid",$id);
			$this->db->update("users",$arr);
			return true;
		}//user_activation_process

		function auth($email,$pass)
		{
			//echo $email;
			//echo $pass;
			// $ans = $this->db->get_where("users",array("uemail"=>$email))->result();

			 $ans = $this->db->select('upass')->get_where("users",array("uemail"=>$email))->result_array();

			 if(count($ans)>0)
			 {
			 	$dbpass = $ans[0]['upass'];

			 	if($dbpass != $pass)
			 	{
			 		return false;
			 	}
			 	else
			 	{
			 		return true;
			 	}
			 }
			 else
			 {
			 	return false;
			 }
		}//auth

		function check_password($pass,$email)
		{
// 			echo $pass;
// 			echo $email;
// exit;
			$ans = $this->db->select('upass')->get_where("users",array("uemail"=>$email))->result_array();

			//print_r($ans);

			$dbpass = $ans[0]['upass'];
			//echo $dbpass;

			if($dbpass==$pass)
			{
				return true;
			}
			else
			{
				return false;
			}
		}//check_password

		function update_password($pass,$email)
		{
			 /*echo $email;
			echo $pass;
			exit;*/
			$data = array(
				"upass"=> $pass
			);

			$this->db->where("uemail",$email);
			return $this->db->update("users",$data);

		}//update_password

		function get_userdata($email)
		{
			 //$ans = $this->db->select('uname,uemail,umobile,ustatus,uprofile')->get_where("users",array("uemail"=>$email))->result_object();

			 $ans = $this->db->select("uid,uname,uemail,umobile,ustatus,uprofile");

			 return $this->db->get_where("users",array("uemail"=>$email))->result();

		}//get_userdata

		function check_email($email)
		{
			return $this->db->select("umobile")->get_where("users",array("uemail"=>$email))->result_array();
		}

		function update_otp($email,$ans)
		{
			//echo $email;
			//echo $ans;
			//exit();

			$data = array("otp"=>$ans);
			$this->db->where("uemail",$email);
			return $this->db->update("users",$data);
		}

		function get_otp($email)
		{
			return $this->db->select("otp")->get_where("users",array("uemail"=>$email))->$result();
		}
		function update_password_for_forgot($pass,$email)
		{
			$data = array("upass"=>$pass);
			$this->db->where("uemail",$email);
			return $this->db->update("users",$data);
		}
		function add_category($data)
		{
			return $this->db->insert("category",$data);
		}
		function add_brand($data)
		{
			return $this->db->insert("brand",$data);
		}

		function get_category()
		{
			return $this->db->get("category")->result_array();
		}
		function get_brand()
		{
			return $this->db->get("brand")->result_array();
		}

		function insert_product($data)
		{
			return $this->db->insert("products",$data);
		}
	}//Admin_model
?>