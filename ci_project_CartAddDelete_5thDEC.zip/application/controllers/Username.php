<?php
/**
 * 
 *//**
  * 
  */

class Username extends CI_Controller{
	
	function index()
	{
		# code...
		//echo "Blog controller class";
		$this->load->view('blogview');
	//	pp();
	}
}
?>
