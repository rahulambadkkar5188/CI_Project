<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {

	
	public function index()
	{
		$this->load->view('index');
	}

	function filtercat($id)
	{
		echo $id;
		$result = $this->myclass->get_products("and category_id ='$id'");

		/*echo "<pre>";
		 print_r($result);
		echo "</pre>";*/

		$this->load->view('filter_cat',array("xyz"=>$result));
	}
	function filterbrand($id)
	{
		echo $id;
		$result = $this->myclass->get_products("and brand_id ='$id'");

		echo "<pre>";
		 print_r($result);
		echo "</pre>";

		if(is_array($result)):
			foreach($result as $val):
	?>

	<div class="col-sm-4">
							<div class="product-image-wrapper">
								<div class="single-products">
										<div class="productinfo text-center">
											<img src="<?php echo base_url();?>assets/products/<?php echo $val['path']?>" alt="" />
											<h2><?php echo $val['price']?></h2>
											<p><?php echo $val['product']?></p>
											<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
										<div class="product-overlay">
										<div class="overlay-content">
											<h2><?php echo $val['price']?></h2>
											<p><?php echo $val['product']?></p>
											<a href="#" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
										</div>
									</div>
										
								</div>
								<div class="choose">
									<ul class="nav nav-pills nav-justified">
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to wishlist</a></li>
										<li><a href="#"><i class="fa fa-plus-square"></i>Add to compare</a></li>
									</ul>
								</div>
							</div>
						</div>
	<?php
		endforeach;
	  endif;
	}

	function cart($id)
	{
		print_r($id);
		$ans = get_cookie("cart");
		print_r($ans);

		if(empty($ans))
		{
			set_cookie("cart",$id,10000,"","/");
			echo "Product Added In Cart";
		}
		else
		{
			echo "2nd pro onward";
			$cartdata = $ans;
			echo $cartdata;
			$arr = explode(",", $cartdata);
			print_r($arr);
			$out = in_array($id,$arr);
			var_dump($out);

			if($out)
			{
				echo "Product Exists in Cart";
			}
			else
			{
				$newpro = $cartdata.",".$id;
				echo $newpro;
				//3,4,5,4
				set_cookie("cart",$newpro,10000,"","/");
				echo "Product Updated in Cart";
			}
		}
	}

	function showcart()
	{
		$this->load->view('cartPage');
	}

	function deletecart($id)
	{
		echo $id;
		$val = get_cookie("cart");
		echo $val;
		$arr = explode(",",$val);
		print_r($arr);
		$pos = array_search($id,$arr);
		echo $pos;

		unset($arr[$pos]);
		print_r($arr);
		$newdata = implode(",", $arr);
		echo $newdata;

		set_cookie("cart",$newdata,10000,"","/");
		// echo "Product Deleted";
	}
}
?>