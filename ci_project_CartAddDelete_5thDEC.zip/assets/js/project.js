$(document).ready(function(){
	var apath="http://localhost/rahula/ci_project/index.php/admin/admin/";
	var basepath="http://localhost/rahula/ci_project/";

	$(".btn-register").click(function(){
		alert(11);
		var form_obj = document.getElementById("register-form");
		alert(form_obj);
		var form_data_obj = new FormData(form_obj);

		alert(form_data_obj);

		$.ajax({

			type: "post",
			data: form_data_obj,
			contentType: false,
			processData: false,
			url : apath + "register_action",
			success: function(res){
				$(".err").html(res)
			}
		})
	}) //.btn-register

	$(".btn-login").click(function(){

		$.ajax({

			type:"post",
			data: $("#login_form").serialize(),
			url : apath + "login_action",
			success: function(res){
				$(".err").html(res)

				if(res == "done")
				{
					//window.location.href = "http://localhost/rahula/ci_project/index.php/admin/admin/index";
					window.location.href = basepath;
				}
			}
		})
	}) //.btn-login

	$(".btn-password").click(function(){

	//	alert(12);
		$.ajax({

			type:"post",
			data: $("#password_form").serialize(),
			url : apath + "password_action",
			success: function(res){
				//alert(res);

				if(res == "done")
				{
					//window.location.href = "http://localhost/rahula/ci_project/index.php/admin/admin/index";
					window.location.href = apath;
				}
				else
				{
					$(".err").html(res);
				}
			}
		})
	}) //.btn-password

	/*----------------------------------------------------------------*/

	$(".form2,.form3").hide();

	$(".btn-forgot1").click(function(){
		$.post(apath + "forgot1_action",$("#forgot1_form").serialize(),function(response){
			console.log(response);
			alert(response)
			if(response == "ok")
			{
				$(".form2,.form1").slideToggle()
			}
			else
			{
				$(".forgot1_err").html(response)
			}
		})
	})//btn-forgot1

	$(".btn-forgot2").click(function(){
		alert(11);
		/*$.post(apath + "forgot2_action",$("#forgot2_form").serialize(),function(response){
			console.log(response);
			alert(response);
			if(response == "ok")
			{
				$(".form2,.form3").slideToggle()
			}
			else
			{
				$(".forgot2_err").html(response)
			}
		})*/
	})//btn-forgot2

	$(".btn-forgot3").click(function(){
		$.post(apath + "forgot3_action",$("#forgot3_form").serialize(),function(response){
			//console.log(response);
				$(".forgot3_err").html(response)
		})
	})//btn-forgot3

	$(".btn-category").click(function(){
		alert(11);
		$.post(apath + "category_action",$("#category_form").serialize(),function(response){
			//console.log(response);
				$(".category_err").html(response)
		})
	})//btn-category

	$(".btn-brand").click(function(){
		$.post(apath + "brand_action",$("#brand_form").serialize(),function(response){
			//console.log(response);
				$(".brand_err").html(response)
		})
	})//btn-brand

   $(".btn-product").click(function(){
  	var form_obj = document.getElementById("product_form");

  	alert(form_obj);
		var form_data_obj = new FormData(form_obj);

		alert(form_data_obj);

		$.ajax({
			type: "post",
			data: form_data_obj,
			contentType: false,
			processData: false,
			url : apath + "product_action",
			success: function(res){
				$(".product_err").html(res)
			}
		})
		
	})//btn-product

 })





	