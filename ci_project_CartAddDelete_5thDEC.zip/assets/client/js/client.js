$(function(){
	var cpath="http://localhost/rahula/ci_project/index.php/client/";
	var basepath="http://localhost/rahula/ci_project/";

	$(".filter_brand").click(function(obj){

		alert(1)		
		obj.preventDefault();
		var rec = $(this).attr("for");
		alert(rec)

		$.post(cpath+"filterbrand/"+rec,function(response){
			console.log(response)
			$(".features_items").html(response)
		})
	})
	$(".add-to-cart").click(function(obj){
		alert(11);
		obj.preventDefault();
		var rec = $(this).attr("for");
		alert(rec);
		$.post(cpath+"cart/"+rec,function(response){
			// console.log(response);
			alert(response)
			//cart
		})
	})

	$(".delete-to-cart").click(function(obj){
		obj.preventDefault();
		var rec = $(this).attr("for");
		alert(rec);

	  $.post(cpath+"deletecart/"+rec,function(response){
			// console.log(response);
			alert(response)
			//cart
			alert("Product Deleted");
			window.location.href=cpath+"/showcart"
		})
	})
})