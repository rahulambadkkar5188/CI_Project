<?php
$this->load->view('admin/header');
?>

<div class="container-fluid">
</div>
  <?php
$this->load->view('admin/footer');
?>
        
 