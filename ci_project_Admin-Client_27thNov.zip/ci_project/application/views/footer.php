<html>
<head>
        <title>My Blog</title>
</head>
<body>
        <h1>Welcome to footer</h1>
        <a href="<?php echo base_url();
        ?>index.php/Userrecord/file_upload">file upload</a>

</body>
</html>