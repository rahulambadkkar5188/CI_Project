<?php
$this->load->view('admin/header');
?>

<div class="container-fluid">
  <div class="card card-register mx-auto mt-5">
        <div class="card-header">Add Brand</div>
        <div class="card-body">
          <form id="brand_form">
              
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputBrand" name="name" class="form-control" placeholder="Email address" required="required">
                <label for="inputEmail">Nike</label>
              </div>
            </div>
            
            <button type="button" class="btn btn-primary btn-block btn-brand">Add</button>
          </form>
        </div>
            <div class="brand_err">  </div>
      </div>
</div>


<?php
	$this->load->view('admin/footer');
?>
        
 