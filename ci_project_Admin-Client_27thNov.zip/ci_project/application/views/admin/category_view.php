<?php
$this->load->view('admin/header');
?>

<div class="container-fluid">
  <div class="card card-register mx-auto mt-5">
        <div class="card-header">Add Category</div>
        <div class="card-body">
          <form id="category_form">
              
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputCategory" name="name" class="form-control" placeholder="Category" required="required">
                <label for="inputEmail">Nike</label>
              </div>
            </div>
            
            <button type="button" class="btn btn-primary btn-block btn-category">Add</button>
          </form>
        </div>
            <div class="category_err">  </div>
      </div>
</div>


<?php
  $this->load->view('admin/footer');
?>
        
 