<?php

/**
 * 
 */
class Blog 
{
	
	function index()
	{
		# code...
		echo "Blog controller class";
	}
	     function pps()
        {
                echo 'Look at this!';
        }
        function shoes($sandals, $id)
        {
                echo $sandals;
                echo $id;
        }
}
?>