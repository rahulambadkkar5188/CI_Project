<?php

/**
 * 
 */
class blog 
{
	
function index()	{
		# code...
	echo "sub dirictory";
	}
}
?>